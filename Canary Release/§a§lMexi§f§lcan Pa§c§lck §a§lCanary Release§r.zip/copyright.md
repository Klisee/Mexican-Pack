Copyright (c) 2024 Klisee

Sobre la cuestion de derechos de autor sobre el Mexican Pack es importante aclarar varios puntos
acerca de la misma ya que para empezar este proyecto cuenta con la Licencia GNU GENERAL PUBLIC
LICENSE 3.0, asi que eres libre de usar el contenido, crear tu fork siempre y cuando des creditos
y uses la misma licencia para tu proyecto.

Asi mismo es importante mencionar que en el paquete de recursos se tienen varias licencias comerciales
principalmente de Origen Mexicano aunque tambien se cuentan con marcas de otros paises en practicamente
toda la textura, es importante aclarar que no fomentamos la promocion de estas marcas comerciales y mas
bien se fomenta la satira hacia las mismas y hacia la Sociedad Mexicana.

Este proyecto aunque esta principalmente administrado por Klisee no es la unica persona encargada del mismo
y el grupo de personas dentro del proyecto se les conoce como el Mexican Team y principalmente Klisee se encarga
de la distrubucion, difusion y las licencias del texture pack.

Una cosa muy importante es que estamos bajo el Fair Use o llamado tambien Uso Justo en Español (Lea: fair-use.md)
y todas las marcas mencionadas en la textura no nos han pagado ni promocionado en esto, ni mucho menos buscamos su
promocion si no mas bien la satira, tambien para aclarar el asunto de derechos de autor y las Normas y EULA de
Mojang Studios™ y nunca buscaremos beneficiarnos monetariamente con este proyecto (Cualquier Uso De Acortadores No
Ets Autorizado Por Nosotros Ni Dado Por Nosotros) ya que rompe la licencia usada para su distribucion.

Respecto a la licencia que usamos es posible redistribuir, modificar y editar la textura siempre y cuando des los
creditos correspondientes y uses la licencia GNU GPL v3.O en todo momento, asi mismo si crearas una modificacion
debera ser libre y que sea totalmente publica para su modificacion asi como usar la licencia Creative Commons Zero 1.0
en todo momento

Sientete en la libertad de resubir la textura pero por favor no la uses bajo fines comerciales como por ejemplo usar
acortadores de publicidad o vender la textura, puedes redistribuirla solo si no incumples esta parte, asi mismo ninguna
marca comercial podra usarlo bajo fines comerciales el paquete de recursos, solo es para uso personal y es posible
usarlo para crear contenido en forma de videos de diferentes plataformas y distribuye con mas personas el archivo
cumpliendo con lo mencionado.

Recuerda que comerciar la textura vendiendola directamente o generando ingresos directamente con acortadores de
publicidad rompe por completo el Fair Use y cualquier reporte que te llegue no me hago responsable ya que dejaria
de ser Fair Use y cualquier empresa que desee reportarte o yo mismo por hacer mal uso del contenido estoy en todo
mi derecho de hacerlo.
