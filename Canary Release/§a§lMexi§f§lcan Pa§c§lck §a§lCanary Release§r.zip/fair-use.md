El Mexican Pack usa licencias comerciales reales pero nosotros usamos el Fair Use para defender nuestro
proyecto el cual no esta ni nunca estara destinado a un uso comercial ni nunca estara hecho para un uso
comercial y como proteccion usamos la Licencia GNU GPL v3.0 para poder dar mejor proteccion al proyecto y
que sea siempre libre y gratuito para siempre.

El uso de todas las marcas en este paquete de recursos de Minecraft™ se nos permite en sus propias Normas
y EULA hacer un uso de este tipo asi como las propias Leyes Mexicanas nos permiten crear esta obra segun 
La Ley Federal del Derecho de Autor, define a los Derechos de Autor, de la siguiente manera:

>  Artículo 11.- El derecho de autor es el reconocimiento que hace el Estado a favor de todo creador de obras 
literarias y artísticas previstas en el artículo 13 de esta Ley, en virtud del cual otorga su protección 
para que el autor goce de prerrogativas y privilegios exclusivos de carácter personal y patrimonial. Los 
primeros integran el llamado derecho moral y los segundos, el patrimonial.

Extraido De: https://www.gob.mx/epn/articulos/conoce-mas-sobre-los-derechos-de-autor

Ya que nosotros no estamos haciendo un uso realmente no permitido de los derechos de autor al menos dentro
de las propias Leyes Mexicanas, que aunque algunas leyes recientes intentan poner algunas trabas por censura
en nuestro caso no aplica realmente ya que no estamos haciendo ningun uso comercial minimo

Sobre que es exactamente el Uso Justo hay una referencia en https://r3d.mx/2020/09/21/la-figura-de-uso-justo-puede-facilitar-el-trabajo-de-preservacion-de-obras-opina-la-fundacion-wikimedia/

El uso justo (también llamado uso legítimo o uso razonable) permitiría a las instituciones culturales preservar 
obras de interés público que todavía no están en el dominio público, algo especialmente importante en un país 
on uno de los estándares más restrictivos de derecho de autor el cual realmente afecte a alguna empresa.
