Algunas texturas del Mexican Pack se basan en las Texturas Vanilla de Minecraft™ - 
las cuales no reclamamos su propiedad a no ser que hayan sido alteradas y las 
texturas y archivos base de la textura son propiedad de Mojang Studios™ 
propiedad de Xbox Game Studios™, una division de Microsoft Corporation™

Los terminos del juego disponibles en https://www.minecraft.net/es-es/terms (Ultima Actualizacion 17 De Abril Del 2020) mencionan que:

> El Contrato de Licencia de Usuario Final de Minecraft [EULA por sus siglas en inglés] y las Directrices 
de Uso de Recursos y Marca ("Políticas") restringen el uso comercial del nombre, la marca y los recursos 
de Minecraft, incluido el software, los gráficos y el audio. Sin embargo, como nos encanta que los jugadores 
y fanáticos hagan cosas divertidas y las compartan con la comunidad, y como entendemos que a veces tengas que 
cobrar para cubrir tus gastos, a continuación explicamos lo que actualmente consideramos comercial y uso comercial. 
Esto puede cambiar con el paso del tiempo pero, por ahora, esperamos que te ayude a entender lo que puedes hacer 
y lo que no, y esperamos que ayude a los amantes de Minecraft a hacer más cosas (y que limite a aquellos que 
intenten pasarse de la raya). Por tanto, redactamos estas Directrices que dan algo de indulgencia en cuanto a 
la actividad comercial, tal y como se describe abajo. No forma parte de las Políticas de la empresa pero existen 
pues, en la actualidad, consideramos que es una buena idea permitir que sucedan algunas de estas cosas. Por favor, 
nota que nos reservamos el derecho de cambiar de opinión en cualquier momento (por ejemplo, si la gente comienza a 
aprovecharse de nuestras buenas intenciones) así como de actualizar las Directrices. Así que, por favor, no creas 
que estas Directrices siempre estarán aquí ni que son definitivas. También queremos aclarar que estas Directrices 
sólo son para la comunidad de jugadores y fanáticos de Minecraft. No autorizan a compañías comerciales, marcas 
corporativas, agencias de publicidad, agencias sin fines de lucro o gobiernos a usar o explotar Minecraft para 
promover productos o servicios que no estén relacionados con Minecraft. Busca más detalles abajo, en la sección 
“Promociones construidas con Minecraft”. Principalmente intentamos permitirles a nuestros maravillosos fanáticos 
hacer cosas maravillosas, los unos para los otros, sin que aparezcan terceros que les arruinen la diversión a todos.


Es muy importante aclarar que aunque el equipo usa marcas comerciales principalmente de origen Mexicano no
es usado para fines comerciones si no mas bien para fines de satira hacia la Sociedad Mexicana y ninguna
marca que aparece en este paquete de textura nos pago de alguna forma y no tenemos relacion alguna con estas
marcas para publicitarlas de alguna forma, El Mexican Team se deslinda de cualquier vinculo con cualquier empresa
y no busca generar algun tipo de ingreso con estas marcas ni de forma directa con el uso de las mismas, ni sera
una textura con la que generemos ingresos por cuestion de derechos de autor "Lea: LICENSE, copyright.md y fair-use.md" para
mas informacion.

Asi mismo queremos recordar que en los terminos de Mojang se nos permite hacer este proyecto bajo el Fair Use.

En https://www.minecraft.net/es-es/terms (Ultima Actualizacion 17 De Abril Del 2020) mencionan que: 

PUEDES:

Hacer cosas que estén específicamente especificadas como excepciones de “acuerdo justo” o “uso justo” 
en las leyes de copyright y marcas comerciales.

El formato de este archivo esta basado en el archivo mojang.md de GeyserOptionalPack disponible en 
https://github.com/GeyserMC/GeyserOptionalPack el cual es Open Source y 100% Modificable y usabe para
diferentes usos, asi mismo aclaramos que la textura tiene partes de la textura original de Mojang
y fue extraida de https://github.com/ZtechNetwork/MCBVanillaBehaviorPack para nuestro uso.