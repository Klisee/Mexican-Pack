Copyright (c) 2023 freesound

Todos los sonidos personalizados son extraidos de freesound.org y cuentan con la licencia CC0 1.0 Universal (CC0 1.0)
Dedicación de Dominio Público de Creative Commons de uso y distribucion libre asi que son totalmente gratuitos y
modificaciones.

Algunos de estos archivos .ogg fueron retocados y cortados para una mejor funcionalidad dentro del Mexican Pack
o mejorar la calidad de los mismos para que sea lo mas disfrutable posible para el jugador, recuerda que eres libre
de tomar estos archivos siempre y cuando hagas la correcta atribucion a la licencia correspondiente de CreativeC
Commons.

No olvides recordar que si haras alguna modificacion al paquete de recursos puedes hacerlo desde GitHub y debes mantener
las licencias asi que los creditos, asi mismo este material musical puedes usarlo sin preocupaciones para videos y streams
ya que son de Dominio Publico.